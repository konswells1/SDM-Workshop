SDM WORKSHOP - STUDENT MATERIALS

1. Create a new RStudio project on your computer.
2. Extract the data/ and scripts/ folders into that project.
3. Follow the published SDM Workshop website.
4. Copy R code into your own annotated .R script.
5. Keep the supplied file names and folder structure.

The data include historical climate, UK elevation,
species records, and a CMIP6 SSP1-2.6 projection
for 2041-2060 (BCC-CSM2-MR).

The supporting script prepare_glm_inputs.R can
reconstruct the standard teaching inputs when needed.

Background locations are not confirmed absences.
See the website for data sources and methodological notes.

# SDM Workshop — independent entry point for Chapter 6 (2026)
# This intentionally reproduces the CORE data-preparation decisions taught in
# Chapter 5, not a second modelling method.
# Use only if Chapter 5's sdm_df_clean and proj_stack are not in the R session.
# No downloads, installations, model fitting or output-file overwrites occur.
# Assumes an RStudio project rooted at the extracted SDM_Workshop folder.

input_files <- c('data/workshop_data.RData', 'data/Clim_UK.tif', 'data/Elev_UK.tif')
missing_files <- input_files[!file.exists(input_files)]
if (length(missing_files)) {
  stop('Open the workshop RStudio project. Missing file(s): ',
       paste(missing_files, collapse = ', '), call. = FALSE)
}
needed_packages <- c('terra', 'sf', 'CoordinateCleaner')
missing_packages <- needed_packages[!vapply(
  needed_packages, requireNamespace, logical(1), quietly = TRUE
)]
if (length(missing_packages)) {
  stop('Required package(s) not installed: ',
       paste(missing_packages, collapse = ', '),
       '. Follow the workshop homepage setup instructions.', call. = FALSE)
}

# Keep the loaded snapshot separate from other objects in the user's session.
snapshot <- new.env(parent = baseenv())
load(input_files[1], envir = snapshot)
for (nm in c('UK_sf', 'occ_df_rhinhipp')) {
  if (!exists(nm, envir = snapshot, inherits = FALSE)) {
    stop('The supplied workshop_data.RData is missing ', nm, call. = FALSE)
  }
}
UK_sf <- snapshot$UK_sf
occ_df_rhinhipp <- snapshot$occ_df_rhinhipp
rm(snapshot)
stopifnot(inherits(UK_sf, 'sf'))

Clim_UK <- terra::rast(input_files[2])
Elev_UK <- terra::rast(input_files[3])
stopifnot(all(c('bio_1', 'bio_12') %in% names(Clim_UK)))

# Recreate the selected three-predictor grid from Chapter 4 / Chapter 5.
climate_template <- Clim_UK[['bio_1']]
if (!terra::same.crs(Elev_UK, climate_template)) {
  Elev_UK_aligned <- terra::project(
    Elev_UK, climate_template, method = 'bilinear')
} else {
  Elev_UK_aligned <- terra::resample(
    Elev_UK, climate_template, method = 'bilinear')
}
names(Elev_UK_aligned) <- 'elevation'
Env_UK_stack <- c(Clim_UK, Elev_UK_aligned)
env_stack <- Env_UK_stack
model_predictors <- c('bio_1', 'bio_12', 'elevation')
proj_stack <- env_stack[[model_predictors]]
stopifnot(terra::compareGeom(climate_template, proj_stack[['elevation']]))

# Recreate precisely the Chapter 5 cleaning decisions.
occ_valid <- as.data.frame(occ_df_rhinhipp)
for (nm in c('decimalLongitude', 'decimalLatitude')) {
  if (!nm %in% names(occ_valid)) stop('Occurrence snapshot missing: ', nm)
  occ_valid[[nm]] <- suppressWarnings(
    as.numeric(as.character(occ_valid[[nm]])))
}
valid_coords <- with(occ_valid,
  is.finite(decimalLongitude) & is.finite(decimalLatitude) &
  decimalLongitude >= -180 & decimalLongitude <= 180 &
  decimalLatitude >= -90 & decimalLatitude <= 90
)
occ_valid <- occ_valid[valid_coords, , drop = FALSE]
if (!'species' %in% names(occ_valid)) {
  occ_valid$species <- 'Rhinolophus hipposideros'
}
occ_valid$species <- as.character(occ_valid$species)
occ_valid$species[is.na(occ_valid$species) |
                    !nzchar(occ_valid$species)] <- 'Rhinolophus hipposideros'
occ_rhinhipp_flags <- CoordinateCleaner::clean_coordinates(
  x = occ_valid,
  lon = 'decimalLongitude', lat = 'decimalLatitude',
  species = 'species',
  tests = c('centroids', 'duplicates', 'equal',
            'gbif', 'institutions', 'zeros'),
  inst_rad = 10000, value = 'spatialvalid', verbose = FALSE
)
flag_summary <- as.logical(occ_rhinhipp_flags$.summary)
flag_summary[is.na(flag_summary)] <- FALSE
occ_rhinhipp_cleaned <- occ_valid[flag_summary, , drop = FALSE]
if (!nrow(occ_rhinhipp_cleaned)) stop('No occurrence records passed cleaning.')

# Retain presences in the UK boundary with complete predictor values.
study_area <- sf::st_transform(UK_sf, terra::crs(proj_stack))
presence_columns <- intersect(
  c('species', 'key', 'decimalLongitude', 'decimalLatitude'),
  names(occ_rhinhipp_cleaned)
)
presence_sf <- sf::st_as_sf(
  occ_rhinhipp_cleaned[, presence_columns, drop = FALSE],
  coords = c('decimalLongitude', 'decimalLatitude'), crs = 4326
)
presence_sf <- sf::st_transform(presence_sf, sf::st_crs(study_area))
inside_region <- lengths(sf::st_intersects(presence_sf, study_area)) > 0
presence_sf <- presence_sf[inside_region, , drop = FALSE]
presence_values <- terra::extract(
  proj_stack, terra::vect(presence_sf), ID = FALSE
)
usable_presence <- stats::complete.cases(presence_values)
presence_sf <- presence_sf[usable_presence, , drop = FALSE]
presence_values <- presence_values[usable_presence, , drop = FALSE]
n_presence <- nrow(presence_sf)
if (n_presence < 5L) stop('Insufficient presences with complete predictors.')

# Recreate Chapter 5's availability mask and background sampling. The seed
# is set BEFORE sampling. These labels are background, NOT true absences.
valid_predictor_cells <- terra::ifel(
  !is.na(proj_stack[['bio_1']]) & !is.na(proj_stack[['bio_12']]) &
    !is.na(proj_stack[['elevation']]), 1, NA
)
sampling_raster <- terra::mask(
  valid_predictor_cells, terra::vect(study_area)
)
set.seed(2222)
n_background <- n_presence
background_points <- terra::spatSample(
  sampling_raster, size = n_background, method = 'random',
  replace = FALSE, na.rm = TRUE, as.points = TRUE,
  values = FALSE, exhaustive = TRUE
)
background_sf <- sf::st_as_sf(background_points)
background_sf$type <- 'background'
background_values <- terra::extract(
  proj_stack, terra::vect(background_sf), ID = FALSE
)
stopifnot(nrow(background_sf) == n_background,
          all(stats::complete.cases(background_values)))

presence_data <- sf::st_sf(
  pa = rep(1L, nrow(presence_sf)), presence_values,
  geometry = sf::st_geometry(presence_sf)
)
background_data <- sf::st_sf(
  pa = rep(0L, nrow(background_sf)), background_values,
  geometry = sf::st_geometry(background_sf)
)
sdm_data <- rbind(presence_data, background_data)
sdm_df <- sf::st_drop_geometry(sdm_data)
sdm_df_clean <- sdm_df[stats::complete.cases(sdm_df), , drop = FALSE]
sdm_df_clean$pa <- as.integer(sdm_df_clean$pa)
stopifnot(all(c('pa', model_predictors) %in% names(sdm_df_clean)))
message('Chapter 5-compatible GLM inputs prepared: ', nrow(sdm_df_clean),
        ' records (', sum(sdm_df_clean$pa == 1L), ' presences; ',
        sum(sdm_df_clean$pa == 0L), ' background).')
